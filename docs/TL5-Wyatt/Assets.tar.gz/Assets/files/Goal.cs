using System;
using UnityEngine;

public class Goal : MonoBehaviour
{
    public event Action Reached;

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<PlayerController>() != null)
            Reached?.Invoke();
    }
}
