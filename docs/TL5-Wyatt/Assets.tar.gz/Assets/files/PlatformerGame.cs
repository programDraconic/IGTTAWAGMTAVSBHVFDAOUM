using System.Collections.Generic;
using UnityEngine;

public class PlatformerGame : MonoBehaviour
{
    [System.Serializable]
    public struct PlatformData
    {
        public Vector2 center;
        public Vector2 size;

        public PlatformData(float x, float y, float width, float height)
        {
            center = new Vector2(x, y);
            size = new Vector2(width, height);
        }
    }

    [Header("Level layout (world units)")]
    public Vector2 playerSpawn = new Vector2(0f, 1f);
    public float playerSize = 1f;
    public Vector2 goalPosition = new Vector2(41f, 6.5f);
    public Vector2 goalSize = new Vector2(0.6f, 2f);
    public float killHeight = -12f;

    public List<PlatformData> platforms = new List<PlatformData>
    {
        new PlatformData(-7.5f, 3f,  1f, 8f),
        new PlatformData( 0f,  -1f, 14f, 2f),
        new PlatformData(10f,  1.5f, 4f, 0.5f),
        new PlatformData(15.5f, 3.5f, 3f, 0.5f),
        new PlatformData(21.5f, 2f,  5f, 0.5f),
        new PlatformData(27f,  4.5f, 2f, 0.5f),
        new PlatformData(32f,  3f,   2f, 6f),
        new PlatformData(39f,  5f,   8f, 1f),
    };

    [Header("Colors")]
    public Color backgroundColor = new Color(0.53f, 0.78f, 0.95f);
    public Color platformColor = new Color(0.22f, 0.25f, 0.32f);
    public Color playerColor = new Color(1f, 0.55f, 0.1f);
    public Color goalColor = new Color(0.2f, 0.8f, 0.3f);

    [Header("Camera")]
    public float cameraSize = 7f;

    Sprite squareSprite;
    PlayerController player;
    float startTime;
    float finishTime;
    bool finished;

    void Start()
    {
        squareSprite = CreateSquareSprite();
        BuildLevel();
        SetupCamera();
        startTime = Time.time;
    }

    void BuildLevel()
    {
        Transform level = new GameObject("Level").transform;

        foreach (PlatformData data in platforms)
            CreateBlock("Platform", data.center, data.size, platformColor, 0, level);

        GameObject goal = CreateBlock("Goal", goalPosition, goalSize, goalColor, 5, level);
        goal.GetComponent<BoxCollider2D>().isTrigger = true;
        goal.AddComponent<Goal>().Reached += OnGoalReached;

        GameObject playerObj = CreateBlock("Player", playerSpawn, Vector2.one * playerSize, playerColor, 10, null);

        SpriteRenderer bodyRenderer = playerObj.GetComponent<SpriteRenderer>();
        GameObject visual = new GameObject("Visual");
        visual.transform.SetParent(playerObj.transform, false);
        SpriteRenderer visualRenderer = visual.AddComponent<SpriteRenderer>();
        visualRenderer.sprite = bodyRenderer.sprite;
        visualRenderer.color = bodyRenderer.color;
        visualRenderer.sortingOrder = bodyRenderer.sortingOrder;
        Destroy(bodyRenderer);

        Rigidbody2D rb = playerObj.AddComponent<Rigidbody2D>();
        rb.freezeRotation = true;
        rb.interpolation = RigidbodyInterpolation2D.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

        playerObj.GetComponent<BoxCollider2D>().sharedMaterial =
            new PhysicsMaterial2D("PlayerNoFriction") { friction = 0f, bounciness = 0f };

        player = playerObj.AddComponent<PlayerController>();
        player.spawnPoint = playerSpawn;
        player.killHeight = killHeight;
        player.visual = visual.transform;
    }

    void SetupCamera()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            cam = new GameObject("Main Camera").AddComponent<Camera>();
            cam.gameObject.tag = "MainCamera";
        }

        cam.orthographic = true;
        cam.orthographicSize = cameraSize;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = backgroundColor;
        cam.transform.position = new Vector3(playerSpawn.x, playerSpawn.y, -10f);

        CameraFollow follow = cam.GetComponent<CameraFollow>();
        if (follow == null) follow = cam.gameObject.AddComponent<CameraFollow>();
        follow.target = player.transform;
        player.cameraShake = follow;
    }

    GameObject CreateBlock(string objName, Vector2 center, Vector2 size, Color color, int sortingOrder, Transform parent)
    {
        GameObject go = new GameObject(objName);
        go.transform.SetParent(parent, false);
        go.transform.position = center;
        go.transform.localScale = new Vector3(size.x, size.y, 1f);

        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = squareSprite;
        sr.color = color;
        sr.sortingOrder = sortingOrder;

        BoxCollider2D col = go.AddComponent<BoxCollider2D>();
        col.size = Vector2.one;
        return go;
    }

    static Sprite CreateSquareSprite()
    {
        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.filterMode = FilterMode.Point;
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1f);
    }

    void OnGoalReached()
    {
        if (finished) return;
        finished = true;
        finishTime = Time.time - startTime;
        Invoke(nameof(RestartRun), 2.5f);
    }

    void RestartRun()
    {
        finished = false;
        player.Respawn();
        startTime = Time.time;
    }

    void OnGUI()
    {
        GUIStyle hud = new GUIStyle(GUI.skin.label) { fontSize = 20 };
        hud.normal.textColor = Color.black;

        float t = finished ? finishTime : Time.time - startTime;
        GUI.Label(new Rect(16, 12, 700, 30), $"Time: {t:0.00}s", hud);
        GUI.Label(new Rect(16, 40, 700, 30), "Move: A/D or Arrow keys    Jump: Space, W or Up", hud);

        if (player != null)
        {
            string impact = player.LastImpact <= 0f ? "soft" : player.LastImpact < 0.5f ? "solid" : "heavy";
            GUI.Label(new Rect(16, 72, 700, 30),
                $"Last jump  height {player.LastJumpHeight:0.0}m   distance {player.LastJumpDistance:0.0}m   landing: {impact}", hud);
            GUI.Label(new Rect(16, 100, 700, 30), $"Best distance: {player.BestJumpDistance:0.0}m", hud);
        }

        if (finished)
        {
            GUIStyle big = new GUIStyle(hud)
            {
                fontSize = 48,
                fontStyle = FontStyle.Bold,
                alignment = TextAnchor.MiddleCenter
            };
            GUI.Label(new Rect(0, 0, Screen.width, Screen.height), $"You made it! {finishTime:0.00}s", big);
        }
    }

    void OnDrawGizmos()
    {
        if (Application.isPlaying || platforms == null) return;

        Gizmos.color = platformColor;
        foreach (PlatformData data in platforms)
            Gizmos.DrawWireCube(data.center, data.size);

        Gizmos.color = playerColor;
        Gizmos.DrawWireCube(playerSpawn, Vector2.one * playerSize);

        Gizmos.color = goalColor;
        Gizmos.DrawWireCube(goalPosition, goalSize);
    }
}
