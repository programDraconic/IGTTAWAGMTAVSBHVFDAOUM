using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(BoxCollider2D))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 8f;
    public float acceleration = 70f;
    public float deceleration = 90f;
    [Range(0f, 1f)] public float airControl = 0.7f;

    [Header("Jumping")]
    public float jumpHeight = 3.5f;
    public float gravityScale = 3f;
    public float fallGravityMultiplier = 1.6f;
    public float shortHopGravityMultiplier = 2.5f;
    public float maxFallSpeed = 20f;
    public float coyoteTime = 0.1f;
    public float jumpBufferTime = 0.12f;
    public float groundCheckDepth = 0.08f;

    [Header("Momentum")]
    [Range(0f, 1f)] public float runningJumpBonus = 0.35f;
    public float takeoffKick = 1.6f;
    public float maxAirSpeed = 12f;
    public float airMomentumDecay = 3.5f;

    [Header("Apex hang time")]
    public float apexThreshold = 3f;
    [Range(0f, 1f)] public float apexGravityMultiplier = 0.55f;
    public float apexControlBonus = 1.4f;

    [Header("Landing impact")]
    public float softLandingDistance = 2f;
    public float hardLandingDistance = 8f;
    public float landingSquash = 0.4f;
    public float airStretch = 0.25f;
    public float squashRecoverySpeed = 5f;
    public float landingLagTime = 0.3f;
    [Range(0f, 1f)] public float landingSlowdown = 0.45f;
    public float landingShake = 0.6f;

    [Header("References")]
    public Transform visual;
    public CameraFollow cameraShake;

    [Header("Respawn")]
    public Vector2 spawnPoint;
    public float killHeight = -12f;

    public bool IsGrounded { get; private set; }
    public float LastJumpHeight { get; private set; }
    public float LastJumpDistance { get; private set; }
    public float LastFallDistance { get; private set; }
    public float LastImpact { get; private set; }
    public float BestJumpDistance { get; private set; }

    Rigidbody2D rb;
    BoxCollider2D box;
    ContactFilter2D groundFilter;
    readonly List<Collider2D> groundHits = new List<Collider2D>();

    float inputX;
    bool jumpHeld;
    float coyoteTimer;
    float jumpBufferTimer;

    bool wasGrounded;
    Vector2 takeoffPoint;
    float peakHeight;
    float landingLagTimer;
    Vector2 squash = Vector2.one;

    Vector2 Velocity
    {
#if UNITY_6000_0_OR_NEWER
        get => rb.linearVelocity;
        set => rb.linearVelocity = value;
#else
        get => rb.velocity;
        set => rb.velocity = value;
#endif
    }

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        box = GetComponent<BoxCollider2D>();
        rb.gravityScale = gravityScale;
        rb.freezeRotation = true;

        groundFilter = new ContactFilter2D();
        groundFilter.SetLayerMask(Physics2D.GetLayerCollisionMask(gameObject.layer));
        groundFilter.useTriggers = false;

        takeoffPoint = transform.position;
        peakHeight = transform.position.y;
    }

    void Update()
    {
        ReadInput(out bool jumpPressed);

        if (jumpPressed) jumpBufferTimer = jumpBufferTime;
        else jumpBufferTimer -= Time.deltaTime;

        if (landingLagTimer > 0f) landingLagTimer -= Time.deltaTime;

        UpdateSquash();

        if (transform.position.y < killHeight) Respawn();
    }

    void FixedUpdate()
    {
        Vector2 v = Velocity;

        IsGrounded = v.y <= 0.01f && CheckGround();

        if (!IsGrounded && wasGrounded) OnLeaveGround();
        if (IsGrounded && !wasGrounded) OnLand(v);
        wasGrounded = IsGrounded;

        if (!IsGrounded) peakHeight = Mathf.Max(peakHeight, transform.position.y);

        if (IsGrounded) coyoteTimer = coyoteTime;
        else coyoteTimer -= Time.fixedDeltaTime;

        bool nearApex = !IsGrounded && Mathf.Abs(v.y) < apexThreshold;

        float speedLimit = moveSpeed;
        if (landingLagTimer > 0f) speedLimit *= landingSlowdown;

        float targetSpeed = inputX * speedLimit;
        float rate = Mathf.Abs(targetSpeed) > 0.01f ? acceleration : deceleration;
        if (!IsGrounded) rate *= airControl;
        if (nearApex) rate *= apexControlBonus;

        bool keepingMomentum = !IsGrounded
            && Mathf.Abs(v.x) > speedLimit
            && Mathf.Abs(targetSpeed) > 0.01f
            && Mathf.Sign(targetSpeed) == Mathf.Sign(v.x);

        v.x = keepingMomentum
            ? Mathf.MoveTowards(v.x, targetSpeed, airMomentumDecay * Time.fixedDeltaTime)
            : Mathf.MoveTowards(v.x, targetSpeed, rate * Time.fixedDeltaTime);

        v.x = Mathf.Clamp(v.x, -maxAirSpeed, maxAirSpeed);

        if (jumpBufferTimer > 0f && coyoteTimer > 0f) v = Jump(v);

        if (nearApex && jumpHeld) rb.gravityScale = gravityScale * apexGravityMultiplier;
        else if (v.y < 0f) rb.gravityScale = gravityScale * fallGravityMultiplier;
        else if (v.y > 0f && !jumpHeld) rb.gravityScale = gravityScale * shortHopGravityMultiplier;
        else rb.gravityScale = gravityScale;

        v.y = Mathf.Max(v.y, -maxFallSpeed);
        Velocity = v;
    }

    Vector2 Jump(Vector2 v)
    {
        float speedRatio = Mathf.Clamp01(Mathf.Abs(v.x) / moveSpeed);
        float height = jumpHeight * (1f + runningJumpBonus * speedRatio);
        float g = Mathf.Abs(Physics2D.gravity.y) * gravityScale;

        v.y = Mathf.Sqrt(2f * g * height);

        if (Mathf.Abs(inputX) > 0.01f)
            v.x = Mathf.Clamp(v.x + Mathf.Sign(inputX) * takeoffKick * speedRatio, -maxAirSpeed, maxAirSpeed);

        jumpBufferTimer = 0f;
        coyoteTimer = 0f;
        landingLagTimer = 0f;
        IsGrounded = false;
        return v;
    }

    void OnLeaveGround()
    {
        takeoffPoint = transform.position;
        peakHeight = transform.position.y;
    }

    void OnLand(Vector2 v)
    {
        LastJumpHeight = Mathf.Max(0f, peakHeight - takeoffPoint.y);
        LastJumpDistance = Mathf.Abs(transform.position.x - takeoffPoint.x);
        LastFallDistance = Mathf.Max(0f, peakHeight - transform.position.y);

        if (LastJumpDistance > BestJumpDistance) BestJumpDistance = LastJumpDistance;

        LastImpact = Mathf.Clamp01(
            (LastFallDistance - softLandingDistance) / Mathf.Max(0.01f, hardLandingDistance - softLandingDistance));

        if (LastImpact > 0f)
        {
            squash = new Vector2(1f + landingSquash * LastImpact * 0.8f, 1f - landingSquash * LastImpact);
            landingLagTimer = landingLagTime * LastImpact;
            if (cameraShake != null) cameraShake.AddShake(landingShake * LastImpact);
        }

        peakHeight = transform.position.y;
    }

    void UpdateSquash()
    {
        if (visual == null) return;

        Vector2 target = Vector2.one;
        if (!IsGrounded)
        {
            float s = Mathf.Clamp(Mathf.Abs(Velocity.y) / maxFallSpeed, 0f, 1f) * airStretch;
            target = new Vector2(1f - s, 1f + s);
        }

        squash = Vector2.MoveTowards(squash, target, squashRecoverySpeed * Time.deltaTime);
        visual.localScale = new Vector3(squash.x, squash.y, 1f);
        visual.localPosition = new Vector3(0f, -(1f - squash.y) * 0.5f, 0f);
    }

    bool CheckGround()
    {
        Bounds b = box.bounds;
        Vector2 point = new Vector2(b.center.x, b.min.y - groundCheckDepth * 0.5f);
        Vector2 size = new Vector2(b.size.x * 0.9f, groundCheckDepth);

        int count = Physics2D.OverlapBox(point, size, 0f, groundFilter, groundHits);
        for (int i = 0; i < count; i++)
        {
            if (groundHits[i] != box) return true;
        }
        return false;
    }

    void ReadInput(out bool jumpPressed)
    {
#if ENABLE_LEGACY_INPUT_MANAGER
        inputX = Input.GetAxisRaw("Horizontal");
        jumpPressed = Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow);
        jumpHeld = Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow);
#elif ENABLE_INPUT_SYSTEM
        var kb = UnityEngine.InputSystem.Keyboard.current;
        if (kb == null)
        {
            inputX = 0f; jumpPressed = false; jumpHeld = false;
            return;
        }
        float right = (kb.dKey.isPressed || kb.rightArrowKey.isPressed) ? 1f : 0f;
        float left = (kb.aKey.isPressed || kb.leftArrowKey.isPressed) ? 1f : 0f;
        inputX = right - left;
        jumpPressed = kb.spaceKey.wasPressedThisFrame || kb.wKey.wasPressedThisFrame || kb.upArrowKey.wasPressedThisFrame;
        jumpHeld = kb.spaceKey.isPressed || kb.wKey.isPressed || kb.upArrowKey.isPressed;
#else
        inputX = 0f; jumpPressed = false; jumpHeld = false;
#endif
    }

    public void Respawn()
    {
        rb.position = spawnPoint;
        transform.position = spawnPoint;
        Velocity = Vector2.zero;
        jumpBufferTimer = 0f;
        coyoteTimer = 0f;
        landingLagTimer = 0f;
        squash = Vector2.one;
        takeoffPoint = spawnPoint;
        peakHeight = spawnPoint.y;
        wasGrounded = false;
    }

    void OnDrawGizmosSelected()
    {
        BoxCollider2D b = box != null ? box : GetComponent<BoxCollider2D>();
        if (b == null) return;
        Bounds bounds = b.bounds;
        Gizmos.color = IsGrounded ? Color.green : Color.red;
        Gizmos.DrawWireCube(
            new Vector3(bounds.center.x, bounds.min.y - groundCheckDepth * 0.5f, 0f),
            new Vector3(bounds.size.x * 0.9f, groundCheckDepth, 0f));
    }
}
