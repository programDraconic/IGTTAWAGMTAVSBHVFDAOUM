using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public Vector2 offset = new Vector2(3f, 1.5f);
    public float smoothTime = 0.15f;

    [Header("Impact shake")]
    public float shakeMagnitude = 0.6f;
    public float shakeFrequency = 22f;
    public float traumaDecay = 1.8f;

    Vector3 basePosition;
    Vector3 velocity;
    float trauma;
    float noiseSeed;

    void Awake()
    {
        basePosition = transform.position;
        noiseSeed = Random.value * 100f;
    }

    public void AddShake(float amount)
    {
        trauma = Mathf.Clamp01(trauma + amount);
    }

    void LateUpdate()
    {
        if (target == null) return;

        Vector3 desired = new Vector3(
            target.position.x + offset.x,
            target.position.y + offset.y,
            basePosition.z);

        basePosition = Vector3.SmoothDamp(basePosition, desired, ref velocity, smoothTime);

        Vector3 shakeOffset = Vector3.zero;
        if (trauma > 0f)
        {
            float strength = trauma * trauma * shakeMagnitude;
            float t = Time.time * shakeFrequency;
            shakeOffset = new Vector3(
                (Mathf.PerlinNoise(noiseSeed, t) * 2f - 1f) * strength,
                (Mathf.PerlinNoise(noiseSeed + 37f, t) * 2f - 1f) * strength,
                0f);
            trauma = Mathf.MoveTowards(trauma, 0f, traumaDecay * Time.deltaTime);
        }

        transform.position = basePosition + shakeOffset;
    }
}
